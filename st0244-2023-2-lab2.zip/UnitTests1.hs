import Test.HUnit
import TicTacToe

emptyBoardTest :: Test
emptyBoardTest = TestCase (emptyBoard == [[Nothing, Nothing, Nothing], [Nothing, Nothing, Nothing], [Nothing, Nothing, Nothing]])

emptyBoardTests :: TestSuite
emptyBoardTests = TestSuite [emptyBoardTest]

main :: IO ()
main = runTestTT emptyBoardTests
