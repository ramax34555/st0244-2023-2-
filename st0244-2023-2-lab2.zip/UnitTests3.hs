import Test.HUnit
import TicTacToe

checkWinnerTest1 :: Test
checkWinnerTest1 = TestCase (checkWinner [[Just X, Nothing, Nothing], [Just X, Nothing, Nothing], [Just X, Nothing, Nothing]] == Just X)

checkWinnerTest2 :: Test
checkWinnerTest2 = TestCase (checkWinner [[Just X, Nothing, Nothing], [Nothing, Just O, Nothing], [Nothing, Nothing, Just O]] == Just O)

checkWinnerTest3 :: Test
checkWinnerTest3 = TestCase (checkWinner [[Just X, Just O, Nothing], [Just O, Just X, Nothing], [Nothing, Nothing, Nothing]] == Nothing)

checkWinnerTests :: TestSuite
checkWinnerTests = TestSuite [checkWinnerTest1, checkWinnerTest2, checkWinnerTest3]

main :: IO ()
main = runTestTT checkWinnerTests
