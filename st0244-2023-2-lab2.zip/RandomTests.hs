import QuickCheck

import TicTacToe

prop_placeMark_emptySquare :: Player -> (Int, Int) -> Board -> Board
prop_placeMark_emptySquare p (x, y) b =
  let newBoard = placeMark p (x, y) b
  in all (any isJust . snd) newBoard

prop_placeMark_occupiedSquare :: Player -> (Int, Int) -> Board -> Property
prop_placeMark_occupiedSquare p (x, y) b =
  let newBoard = placeMark p (x, y) b
  in error "Trying to place a mark on an occupied square" `shouldThrow`

quickCheck prop_placeMark_emptySquare
quickCheck prop_placeMark_occupiedSquare
