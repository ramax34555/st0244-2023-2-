module TicTacToe where

import Data.List (sort, intercalate)

-- Define the two players, X and O
data Player = X | O deriving (Show, Ord)

-- Define the game board as a 2D list of Players
type Board = [[Player]]

-- Create an empty game board
emptyBoard :: Board
emptyBoard = [[Nothing, Nothing, Nothing], [Nothing, Nothing, Nothing], [Nothing, Nothing, Nothing]]

-- Function to place a player's mark on the board at a given position (x, y)
placeMark :: Player -> (Int, Int) -> Board -> Board
placeMark p (x, y) b =
  if b !! x !! y == Nothing
    -- If the cell is empty, replace it with the player's mark
    then replaceElem x (replaceElem y (Just p) (b !! x)) b
    -- If the cell is already occupied, throw an error
    else error "Trying to place a mark on an occupied square"

-- Helper function to replace an element at a specific index in a list
replaceElem :: Int -> a -> [a] -> [a]
replaceElem i x xs = take i xs ++ [x] ++ drop (i + 1) xs

-- Function to check if a player has won the game
checkWinner :: Board -> Maybe Player
checkWinner b =
  let rows = transpose b -- Transpose the board to check columns and diagonals
      -- Define the two diagonal patterns to check
      diags = [[b !! x !! y | x <- [0, 1, 2], y <- [0 .. x]],
               [b !! x !! y | x <- [0, 1, 2], y <- [2, 1, 0]]]
  in
    -- Check if any row, column, or diagonal contains three of the same player's marks
    -- If any of them do, return the winning player (X or O)
    -- If no player has won, this will return Nothing
    if any (all (== Just p)) rows || any (all (== Just p)) diags
      then Just p
      else Nothing

-- Function to check if the game is over
gameOver :: Board -> Maybe Player
gameOver b =
  -- Check if there is a winner using the checkWinner function
  checkWinner b
  -- If there's no winner, check if all cells are occupied (a tie)
  <|> (if all (all isJust) b then Just Nothing else Nothing)

-- Function to make a move and return the updated board
play :: Player -> (Int, Int) -> Board -> Board
play p (x, y) b =
  let newBoard = placeMark p (x, y) b -- Place the player's mark on the board
      winner = checkWinner newBoard   -- Check if there's a winner
  in
    -- If there's no winner, return the new board
    -- If there's a winner, return the same board (the game is over)
    if winner == Nothing then newBoard else b

-- Function to display the game board as a string
displayBoard :: Board -> String
displayBoard b =
  intercalate "\n" . map (intercalate " | ") $ b

-- Main function for running the game
main :: IO ()
main = do
  putStrLn "Tic-tac-toe game!\n"
  putStrLn "Do you want to play first or second? (f/s) "
  input <- getLine
  let player = if input == "f" then X else O
  let board = if player == X then emptyBoard else play O (1, 1) emptyBoard
  putStrLn $ displayBoard board
