import Test.HUnit
import TicTacToe

placeMarkTest :: Test
placeMarkTest = TestCase (placeMark X (1, 1) emptyBoard == [[Just X, Nothing, Nothing], [Nothing, Nothing, Nothing], [Nothing, Nothing, Nothing]])

placeMarkTests :: TestSuite
placeMarkTests = TestSuite [placeMarkTest]

main :: IO ()
main = runTestTT placeMarkTests
