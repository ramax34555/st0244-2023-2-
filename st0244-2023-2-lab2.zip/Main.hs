module TicTacToe where

import Data.List (sort, intercalate)

data Player = X | O deriving (Show, Ord)

type Board = [[Player]]

emptyBoard :: Board
emptyBoard = [[Nothing, Nothing, Nothing], [Nothing, Nothing, Nothing],
              [Nothing, Nothing, Nothing]]

placeMark :: Player -> (Int, Int) -> Board -> Board
placeMark p (x, y) b =
  if b !! x !! y == Nothing
  then b !! x !! y <- Just p
  else error "Trying to place a mark on an occupied square"

checkWinner :: Board -> Maybe Player
checkWinner b =
  let rows = transpose b
      diags = [[b !! x !! y | x <- [0, 1, 2], y <- [0 .. x]],
                [b !! x !! y | x <- [0, 1, 2], y <- [2 .. x]]]
  in any (all (== Just p)) rows ++ diags

gameOver :: Board -> Maybe Player
gameOver b = checkWinner b <|> (if all (any isJust . snd) b then Just Nothing else Nothing)

play :: Player -> (Int, Int) -> Board -> Board
play p (x, y) b =
  let (newBoard, winner) = placeMark p (x, y) b
  in if winner == Nothing then newBoard else newBoard

displayBoard :: Board -> String
displayBoard b =
  intercalate "\n" . map (intercalate " | ") $ b

main :: IO ()
main = do
  putStrLn "Tic-tac-toe game!\n"
  putStrLn "Do you want to play first or second? (f/s) "
  input <- getLine
  let player = if input == "f" then X else O
  let board = if player == X then emptyBoard else play O (1, 1) emptyBoard
  putStrLn $ displayBoard board
